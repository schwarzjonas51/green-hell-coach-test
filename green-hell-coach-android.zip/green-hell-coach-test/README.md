# Green Hell Coach – Android-Prototyp

Android-App (Android 8.0 oder neuer) für kameraerfasste Rundenzeiten mit deutschem Sprachfeedback. CameraX liefert das Kamerabild, das mitgelieferte ML-Kit-Modell erkennt Text lokal. Die App überträgt keine Kamerabilder und benötigt keinen API-Schlüssel. Die Android-Sprachengine kann abhängig von ihren Einstellungen eine Netzwerkverbindung benötigen.

## Installieren

Unter **Actions → Android APK** den erfolgreichen Build öffnen und das Artefakt **green-hell-coach-debug** herunterladen und entpacken. `app-debug.apk` auf das Handy übertragen und installieren; Android fragt gegebenenfalls nach der Erlaubnis für Installationen aus dieser Quelle. Das ist eine Debug-Version, keine Play-Store-Veröffentlichung.

Alternativ in Android Studio öffnen, JDK 17 und Android SDK 35 verwenden, synchronisieren und auf einem angeschlossenen Android-Handy mit **Run** starten. Ohne Android Studio: Gradle 8.9 installieren, dann `gradle testDebugUnitTest assembleDebug`. Es ist noch kein Gradle Wrapper eingecheckt.

## Verwenden

1. Kamera erlauben und Handy fest vor dem Spielbildschirm aufstellen. Reflexionen und unscharfe Schrift vermeiden.
2. Im Spiel die **letzte abgeschlossene Rundenzeit** einblenden. Mit Horizontal, Vertikal, Breite und Höhe den Ausschnitt so einstellen, dass nur diese eine Zeit sichtbar ist. Das kleine Vorschaubild zeigt exakt den OCR-Ausschnitt. Format: `8:12.345` oder `8:12,345`.
3. **Coaching starten** drücken. Eine Zeit muss mindestens 1,8 Sekunden unverändert und eindeutig erkannt werden. Die erste Zeit setzt die Referenz; die nächste geänderte Zeit wird mit der vorherigen Runde verglichen und auf Deutsch angesagt.
4. **Coaching pausieren** stoppt Ansagen. **Neue Sitzung** löscht die Referenz und Bestzeit. Änderungen am Ausschnitt setzen die Sitzung zurück und pausieren das Coaching.

Wenn keine Stimme zu hören ist, deutsche Sprachdaten in den Android-Einstellungen für Text-in-Sprache installieren und Medienlautstärke prüfen. Beim Wechsel in den Hintergrund wird das Coaching pausiert.

## Grenzen der ersten Version

- Zeitbasiertes Livefeedback bei einer neu erkannten abgeschlossenen Runde; keine Analyse von Bremspunkten, Ideallinie oder Pedalen.
- Es muss die eingefrorene letzte Rundenzeit erfasst werden. Ein angehaltener laufender Timer kann fälschlich als Runde gelten. Eine bereits beim Start sichtbare letzte Runde zählt als Referenz.
- Zwei direkt aufeinanderfolgende identische Rundenzeiten lassen sich ohne Rundenzähler nicht unterscheiden und werden nicht erneut gezählt. Unterschiedliche stabile OCR-Fehler können fälschlich zählen.
- Noch keine dauerhafte Speicherung, spielbezogene HUD-Profile oder Hintergrundaufzeichnung.
- Reale Kamera-/Bildschirm-Erkennung und Sprachausgabe müssen auf einem Android-Handy geprüft werden. Unit-Tests prüfen Zeitformat, Stabilisierung, Mehrdeutigkeit und Duplikate; sie ersetzen den Gerätetest nicht.

## Gerätetest

Kameraberechtigung ablehnen und erneut erlauben; Ausschnitt einstellen; `8:12.345` mindestens zwei Sekunden anzeigen, dann `8:11.345`: Erwartet werden zwei erfasste Runden und eine Bestzeitansage. Unveränderte Anzeige darf nicht erneut zählen. Laufende Zeit, unscharfe Anzeige und zwei Zeiten im Ausschnitt dürfen keine Runde auslösen. Pause, neue Sitzung und Hintergrundwechsel prüfen. Abschließend mit dem echten Spiel-HUD testen.
