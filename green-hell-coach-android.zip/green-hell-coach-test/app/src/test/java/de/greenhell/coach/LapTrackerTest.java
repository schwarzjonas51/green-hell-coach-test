package de.greenhell.coach;

import org.junit.Test;
import static org.junit.Assert.*;

public class LapTrackerTest {
    @Test public void parsesOnlyOneUnambiguousTime() {
        assertEquals(492345, LapTracker.parse("LAST 8:12.345"));
        assertEquals(492345, LapTracker.parse("8:12,345"));
        assertEquals(-1, LapTracker.parse("8:12.345 8:11.123"));
        assertEquals(-1, LapTracker.parse("8:72.345"));
        assertEquals(-1, LapTracker.parse("0:00.000"));
        assertEquals(-1, LapTracker.parse("8:12.3456"));
    }
    @Test public void waitsForStableTimeAndSuppressesDuplicates() {
        LapTracker t = new LapTracker();
        assertNull(t.observe("8:12.345", 0));
        assertNull(t.observe("8:12.345", 1799));
        assertNotNull(t.observe("8:12.345", 1800));
        assertNull(t.observe("8:12.345", 10000));
        assertNull(t.observe("8:11.345", 11000));
        assertTrue(t.observe("8:11.345", 12800).contains("Neue Bestzeit"));
        assertTrue(t.summary().contains("Runden: 2"));
    }
    @Test public void runningTimerAndOcrDropoutsDoNotCount() {
        LapTracker t = new LapTracker();
        for (int i=0; i<10; i++) assertNull(t.observe("8:12." + (100+i), i*400));
        assertNull(t.observe("8:12.345", 5000));
        assertNull(t.observe("", 6500));
        assertNull(t.observe("8:12.345", 6800));
        assertNull(t.observe("8:12.345", 8000));
        assertNotNull(t.observe("8:12.345", 8600));
    }
}
