package de.greenhell.coach;

import android.graphics.Bitmap;

/** Experimental HUD color detector. Values mean colored pixel coverage, not physical pedal travel. */
public final class PedalDetector {
    public static final class Reading {
        public final int gas, brake;
        public final boolean visible;
        Reading(int gas, int brake, boolean visible) { this.gas=gas; this.brake=brake; this.visible=visible; }
    }
    public static Reading measure(Bitmap source, int centerX, int centerY, int boxWidth, int boxHeight) {
        if (source == null) return new Reading(0,0,false);
        int sw=source.getWidth(), sh=source.getHeight();
        int w=Math.max(1,sw*Math.max(5,boxWidth)/100), h=Math.max(1,sh*Math.max(5,boxHeight)/100);
        int left=(sw-w)*Math.max(0,Math.min(100,centerX))/100;
        int top=(sh-h)*Math.max(0,Math.min(100,centerY))/100;
        int greens=0, reds=0, checked=0;
        int step=Math.max(1,Math.min(w,h)/70);
        for(int yy=top;yy<top+h;yy+=step) for(int xx=left;xx<left+w;xx+=step) {
            int c=source.getPixel(xx,yy), r=(c>>16)&255, g=(c>>8)&255, b=c&255;
            checked++;
            if(g>85 && g>r*1.35f && g>b*1.20f) greens++;
            if(r>100 && r>g*1.42f && r>b*1.35f) reds++;
        }
        // Coverage is deliberately normalized against modest HUD coverage, not called pedal position.
        int gas=Math.min(100,(int)(100f*greens/Math.max(1,checked)*6));
        int brake=Math.min(100,(int)(100f*reds/Math.max(1,checked)*6));
        return new Reading(gas,brake,greens+reds > checked*0.003f);
    }
}
