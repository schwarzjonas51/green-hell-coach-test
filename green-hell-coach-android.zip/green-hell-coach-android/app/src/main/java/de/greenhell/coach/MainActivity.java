package de.greenhell.coach;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.MediaPlayer;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    private static final int BG=0xFF101014, PANEL=0xFF22222B, ORANGE=0xFFFF6A00, RED=0xFFE53935, GOLD=0xFFFFC247, WHITE=0xFFF7F7F7, MUTED=0xFFB8B9C1;
    private final ExecutorService cameraExecutor=Executors.newSingleThreadExecutor();
    private final TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private LapTracker tracker=new LapTracker();
    private PreviewView preview;
    private TextView status, lapText, pedalText, commentaryText, modeText;
    private ProgressBar gasBar, brakeBar;
    private TextToSpeech speech;
    private boolean speechReady=false, listening=false, destroyed=false, busy=false;
    private long lastFrame=0, lastAnnounce=0, lastEvent=0;
    private int mode=1, intensity=1, eventCounter=0, lastGas=0, lastBrake=0;
    // Sliders map the desired HUD regions from the full camera image (0..100%).
    private int lapX=50, lapY=12, lapW=35, lapH=15;
    private int pedalX=94, pedalY=85, pedalW=12, pedalH=26;
    private ProcessCameraProvider cameraProvider;
    private Button startButton;
    private LinearLayout root;
    private MediaPlayer menuMusic;
    private final Handler menuHandler=new Handler(Looper.getMainLooper());
    private boolean menuActive=false, menuSound=true;
    private int storyIndex=0;
    private final String[] stories={
        "Willkommen in der Grünen Hölle. Die Nordschleife am Nürburgring wurde 1927 eröffnet und zählt zu den anspruchsvollsten Rennstrecken der Welt.",
        "Über zwanzig Kilometer Asphalt, unzählige Höhenwechsel und berühmte Kurven: Hier zählt Konzentration in jeder Sekunde.",
        "Von der Fuchsröhre bis zum Karussell: Die Nordschleife schreibt Motorsportgeschichte. Jede Runde ist eine neue Herausforderung.",
        "Green Hell Coach begleitet dein Rennen. Wähle deinen Fahrcoach, den Live-Kommentator oder sieh dir deine Rundenstatistik an."
    };
    private final Runnable nextStory=new Runnable(){@Override public void run(){
        if(!menuActive||!menuSound)return;
        if(menuMusic!=null)menuMusic.setVolume(.12f,.12f);
        if(speechReady&&speech!=null)speech.speak(stories[storyIndex++%stories.length],TextToSpeech.QUEUE_FLUSH,null,"menu-story");
        menuHandler.postDelayed(()->{if(menuActive&&menuSound&&menuMusic!=null)menuMusic.setVolume(.38f,.38f);},14500);
        menuHandler.postDelayed(this,31000);
    }};
    private final ActivityResultLauncher<String> cameraPermission=registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
        if(granted) openCamera(); else if(status!=null)status.setText("Kamerazugriff fehlt. Bitte in den Einstellungen erlauben.");
    });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        speech=new TextToSpeech(this,result->{if(destroyed)return;if(result==TextToSpeech.SUCCESS && speech!=null){int r=speech.setLanguage(Locale.GERMANY);speechReady=(r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED);speech.setSpeechRate(.92f);}});
        showHome();
    }
    private void setScreen(LinearLayout content){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content);setContentView(scroll);
    }
    private LinearLayout screen(){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(22),dp(18),dp(28));
        c.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF17171B,0xFF100C0E,0xFF27130A}));return c;
    }
    private void showHome(){
        menuActive=true;listening=false;if(cameraProvider!=null)cameraProvider.unbindAll();
        LinearLayout home=screen();setScreen(home);
        TextView eyebrow=label(home,"NÜRBURGRING  /  GT3 EXPERIENCE",12,GOLD,true);eyebrow.setGravity(Gravity.CENTER);
        TextView title=label(home,"GREEN HELL",36,ORANGE,true);title.setGravity(Gravity.CENTER);
        TextView sub=label(home,"C O A C H     V 2",21,WHITE,true);sub.setGravity(Gravity.CENTER);
        TextView line=label(home,"DEINE RUNDE. DEIN RENNEN. DEIN COACH.",11,MUTED,true);line.setGravity(Gravity.CENTER);
        LinearLayout hero=card(home);hero.setPadding(dp(18),dp(26),dp(18),dp(26));
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.BR_TL,new int[]{0xFF7C270D,0xFF2A191A,0xFF171A20}));
        TextView flag=label(hero,"🏁   THE GREEN HELL",24,WHITE,true);flag.setGravity(Gravity.CENTER);
        TextView legend=label(hero,"NORDSCHLEIFE  •  20,8 KM  •  RENNSPORT",12,GOLD,true);legend.setGravity(Gravity.CENTER);
        label(home,"WÄHLE DEINEN MODUS",14,GOLD,true);
        action(home,"🏎  COACH & ANALYSE     ›",ORANGE).setOnClickListener(v->showDashboard(0));
        label(home,"       Live-Fahrhinweise und erkannte Rundenzeiten",12,MUTED,false);
        action(home,"🎙  RENNKOMMENTATOR     ›",RED).setOnClickListener(v->showDashboard(1));
        label(home,"       Deutsche Rennbegleitung mit Sprachausgabe",12,MUTED,false);
        action(home,"🏆  STATISTIKEN     ›",0xFF4A3031).setOnClickListener(v->showStats());
        label(home,"       Letzte Runde, Bestzeit und Rundenübersicht",12,MUTED,false);
        Button audio=action(home,menuSound?"🔊  MENÜ-TON: AN":"🔇  MENÜ-TON: AUS",PANEL);
        audio.setOnClickListener(v->{menuSound=!menuSound;audio.setText(menuSound?"🔊  MENÜ-TON: AN":"🔇  MENÜ-TON: AUS");if(menuSound)startMenuAudio();else stopMenuAudio();});
        TextView foot=label(home,"Musik und Geschichten wechseln sich ab. Im Fahrmodus bleibt die Menü-Erzählung stumm.",12,MUTED,false);foot.setGravity(Gravity.CENTER);
        startMenuAudio();
    }
    private void startMenuAudio(){
        stopMenuAudio();if(!menuActive||!menuSound)return;
        try{menuMusic=MediaPlayer.create(this,R.raw.racing_loop);if(menuMusic!=null){menuMusic.setLooping(true);menuMusic.setVolume(.38f,.38f);menuMusic.start();}}catch(Exception ignored){}
        menuHandler.postDelayed(nextStory,8500);
    }
    private void stopMenuAudio(){menuHandler.removeCallbacksAndMessages(null);if(speech!=null)speech.stop();if(menuMusic!=null){menuMusic.release();menuMusic=null;}}
    private void enterMode(){menuActive=false;stopMenuAudio();}
    private void showStats(){enterMode();LinearLayout content=screen();setScreen(content);
        action(content,"‹  ZURÜCK ZUM HAUPTMENÜ",PANEL).setOnClickListener(v->showHome());
        label(content,"🏆  STATISTIKEN",28,ORANGE,true);label(content,"DEINE AKTUELLE SITZUNG",13,GOLD,true);
        LinearLayout results=card(content);label(results,"RUNDENÜBERSICHT",15,GOLD,true);label(results,tracker.summary(),20,WHITE,true);
        label(results,"Die Zeiten stammen aus der Kamera-Erkennung. Nur erkannte, stabile Rundenzeiten werden übernommen.",13,MUTED,false);
        action(content,"COACH & ANALYSE ÖFFNEN",ORANGE).setOnClickListener(v->showDashboard(0));
    }
    private void showDashboard(int selected){enterMode();mode=selected;listening=false;
        LinearLayout content=screen();setScreen(content);
        action(content,"‹  ZURÜCK ZUM HAUPTMENÜ",PANEL).setOnClickListener(v->showHome());
        TextView header=label(content,"GREEN HELL",29,ORANGE,true);
        label(content,selected==0?"COACH & ANALYSE":"RENNKOMMENTATOR",15,GOLD,true);
        label(content,"NORDSCHLEIFE   •   GT3   •   LIVE",12,MUTED,false);
        LinearLayout viewCard=card(content);
        label(viewCard,"●  LIVE-KAMERA",15,GOLD,true);
        preview=new PreviewView(this);preview.setScaleType(PreviewView.ScaleType.FIT_CENTER);
        viewCard.addView(preview,new LinearLayout.LayoutParams(-1,dp(215)));
        status=label(viewCard,"Kamera wird gestartet …",13,MUTED,false);
        LinearLayout timerCard=card(content);
        label(timerCard,"RUNDENANALYSE",14,ORANGE,true);
        lapText=label(timerCard,tracker.summary(),18,WHITE,true);
        LinearLayout barsCard=card(content);
        label(barsCard,"PEDAL-HUD  ·  EXPERIMENTELL",14,ORANGE,true);
        label(barsCard,"GAS  (GRÜN)",13,WHITE,true);
        gasBar=bar(barsCard,0xFF37D67A);
        label(barsCard,"BREMSE  (ROT)",13,WHITE,true);
        brakeBar=bar(barsCard,RED);
        pedalText=label(barsCard,"Suche farbige Balken im ausgewählten Bildbereich …",12,MUTED,false);
        LinearLayout speechCard=card(content);
        label(speechCard,"🎙  FUNK & KOMMENTATOR",14,ORANGE,true);
        modeText=label(speechCard,"Kommentator · Normal",16,WHITE,true);
        commentaryText=label(speechCard,"Warte auf erkannte Rundenzeiten oder Pedalwechsel.",14,MUTED,false);
        startButton=action(speechCard,"▶  COACHING STARTEN",ORANGE);
        startButton.setOnClickListener(v->{listening=!listening;startButton.setText(listening?"Ⅱ  COACHING PAUSIEREN":"▶  COACHING STARTEN");
            if(!listening && speech!=null)speech.stop();
            if(listening){announce("Green Hell Coach aktiv. Viel Erfolg auf der Nordschleife!",true); status.setText("Live-Coaching aktiviert.");}
            else status.setText("Coaching pausiert.");});
        action(speechCard,"SPRACHMODUS WECHSELN",RED).setOnClickListener(v->{mode=(mode+1)%3;refreshMode();});
        action(speechCard,"INTENSITÄT WECHSELN",PANEL).setOnClickListener(v->{intensity=(intensity+1)%3;refreshMode();});
        action(speechCard,"NEUE SITZUNG",PANEL).setOnClickListener(v->{ // tracker kept simple: reinitialize with explicit reset method
            resetLapTracker();lastGas=0;lastBrake=0;lastEvent=0;lapText.setText(tracker.summary());commentaryText.setText("Neue Sitzung bereit.");
        });
        LinearLayout settings=card(content);
        label(settings,"⚙  BILDAUSSCHNITTE EINSTELLEN",14,GOLD,true);
        label(settings,"Rundenzeit: nur die eingefrorene LETZTE RUNDENZEIT auswählen (nicht den laufenden Timer).",12,MUTED,false);
        slider(settings,"Zeit links/rechts",lapX,v->lapX=v);
        slider(settings,"Zeit oben/unten",lapY,v->lapY=v);
        slider(settings,"Zeit Breite",lapW,v->lapW=Math.max(5,v));
        slider(settings,"Zeit Höhe",lapH,v->lapH=Math.max(5,v));
        label(settings,"Pedale: unteren rechten HUD-Bereich mit roten/grünen Balken auswählen.",12,MUTED,false);
        slider(settings,"Pedale links/rechts",pedalX,v->pedalX=v);
        slider(settings,"Pedale oben/unten",pedalY,v->pedalY=v);
        slider(settings,"Pedale Breite",pedalW,v->pedalW=Math.max(5,v));
        slider(settings,"Pedale Höhe",pedalH,v->pedalH=Math.max(5,v));
        action(settings,"KAMERA ERNEUT STARTEN",PANEL).setOnClickListener(v->requestCamera());
        label(content,"BETA-HINWEIS: Die Farberkennung misst Farbanteile im Kamerabild, keine echten Pedalstellungen. Fahrfehler, Kurven und Bremsmarken können damit noch nicht zuverlässig bestimmt werden.",12,MUTED,false);
        refreshMode();requestCamera();
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView label(LinearLayout into,String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(4),dp(7),dp(4),dp(7));into.addView(t);return t;}
    private LinearLayout card(LinearLayout parent){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(13),dp(12),dp(13),dp(13));c.setBackground(shape(PANEL,17));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(13);parent.addView(c,p);return c;}
    private Button action(LinearLayout parent,String name,int color){Button b=new Button(this);b.setText(name);b.setAllCaps(false);b.setTextColor(WHITE);b.setTypeface(null,Typeface.BOLD);b.setBackground(shape(color,11));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(49));p.topMargin=dp(9);parent.addView(b,p);return b;}
    private ProgressBar bar(LinearLayout parent,int tint){ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(100);p.setProgressTintList(android.content.res.ColorStateList.valueOf(tint));p.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF44444F));LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(-1,dp(13));layout.bottomMargin=dp(7);parent.addView(p,layout);return p;}
    private interface Change{void changed(int value);}
    private void slider(LinearLayout parent,String name,int initial,Change callback){TextView title=label(parent,name+": "+initial+"%",12,MUTED,false);SeekBar b=new SeekBar(this);b.setMax(100);b.setProgress(initial);b.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));parent.addView(b);b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
        public void onProgressChanged(SeekBar s,int v,boolean user){title.setText(name+": "+v+"%");callback.changed(v);}
        public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
    });}
    private void refreshMode(){String[] types={"Renningenieur","Kommentator","Stumm"};String[] levels={"Ruhig","Normal","Volle Action"};modeText.setText(types[mode]+" · "+levels[intensity]);if(speech!=null)speech.stop();}
    private void resetLapTracker(){tracker=new LapTracker();}
    private void requestCamera(){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)openCamera();else cameraPermission.launch(Manifest.permission.CAMERA);}
    private void openCamera(){var future=ProcessCameraProvider.getInstance(this);future.addListener(()->{if(destroyed)return;try{
        cameraProvider=future.get();cameraProvider.unbindAll();
        Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
        ImageAnalysis a=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
        a.setAnalyzer(cameraExecutor,this::analyze);cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,a);
        status.setText("Kamera bereit. HUD einstellen und Coaching starten.");
    }catch(Exception e){status.setText("Kamera konnte nicht gestartet werden: "+e.getMessage());}},ContextCompat.getMainExecutor(this));}
    private void analyze(ImageProxy frame){long now=SystemClock.elapsedRealtime();if(busy||now-lastFrame<450){frame.close();return;}busy=true;lastFrame=now;
        try{
            Bitmap raw=frame.toBitmap();Matrix m=new Matrix();m.postRotate(frame.getImageInfo().getRotationDegrees());
            Bitmap image=Bitmap.createBitmap(raw,0,0,raw.getWidth(),raw.getHeight(),m,true);
            frame.close();
            int cw=Math.max(1,image.getWidth()*Math.max(5,lapW)/100),ch=Math.max(1,image.getHeight()*Math.max(5,lapH)/100);
            int cx=(image.getWidth()-cw)*lapX/100,cy=(image.getHeight()-ch)*lapY/100;
            Bitmap crop=Bitmap.createBitmap(image,cx,cy,cw,ch);
            PedalDetector.Reading p=PedalDetector.measure(image,pedalX,pedalY,pedalW,pedalH);
            runOnUiThread(()->updatePedals(p));
            recognizer.process(InputImage.fromBitmap(crop,0))
                .addOnSuccessListener(result->{if(destroyed)return;int value=LapTracker.parse(result.getText());
                    if(listening){String msg=tracker.observe(result.getText(),SystemClock.elapsedRealtime());if(msg!=null){lapText.setText(tracker.summary());announce(msg,true);}}
                    if(value>=0)status.setText("Erkannte Zeit: "+LapTracker.format(value));})
                .addOnFailureListener(e->{if(!destroyed)status.setText("Zeitenerkennung fehlgeschlagen. Ausschnitt überprüfen.");})
                .addOnCompleteListener(task->busy=false);
        }catch(Exception e){frame.close();busy=false;}
    }
    private void updatePedals(PedalDetector.Reading r){if(destroyed)return;gasBar.setProgress(r.gas);brakeBar.setProgress(r.brake);
        pedalText.setText(r.visible?("Farbsignal: Grün "+r.gas+"%  ·  Rot "+r.brake+"% (Bildanteil)"):"Keine zuverlässigen roten/grünen HUD-Farben erkannt");
        int beforeBrake=lastBrake,beforeGas=lastGas;lastBrake=r.brake;lastGas=r.gas;
        if(!listening||!r.visible||mode==2)return;
        long now=SystemClock.elapsedRealtime();int cooldown=new int[]{32000,18000,9000}[intensity];
        if(now-lastEvent<cooldown)return;
        if(beforeBrake<25&&r.brake>=45){lastEvent=now;announce(mode==0?"Bremsanzeige erkannt. Achte auf einen sauberen Übergang.":"Da geht er auf die Bremse! Die nächste Passage wird spannend!",false);}
        else if(beforeGas<25&&r.gas>=50){lastEvent=now;announce(mode==0?"Gas-Signal erkannt. Beschleunige kontrolliert.":"Das Gaspedal-Signal steigt! Der GT3 nimmt wieder Fahrt auf!",false);}
    }
    private void announce(String message,boolean important){commentaryText.setText(message);if(!listening||mode==2||!speechReady)return;
        long now=SystemClock.elapsedRealtime();if(!important&&now-lastAnnounce<4500)return;lastAnnounce=now;
        speech.speak(message,important?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"ghc-"+now);
    }
    @Override protected void onStop(){super.onStop();listening=false;stopMenuAudio();if(startButton!=null)startButton.setText("▶  COACHING STARTEN");if(speech!=null)speech.stop();}
    @Override protected void onStart(){super.onStart();if(menuActive&&menuSound)startMenuAudio();}
    @Override public void onBackPressed(){if(menuActive)super.onBackPressed();else showHome();}
    @Override protected void onDestroy(){destroyed=true;stopMenuAudio();if(cameraProvider!=null)cameraProvider.unbindAll();cameraExecutor.shutdown();recognizer.close();if(speech!=null){speech.stop();speech.shutdown();}super.onDestroy();}
}
