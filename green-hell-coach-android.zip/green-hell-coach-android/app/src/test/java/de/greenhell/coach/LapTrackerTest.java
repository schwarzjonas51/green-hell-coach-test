package de.greenhell.coach;

import org.junit.Test;
import static org.junit.Assert.*;

public class LapTrackerTest {
 @Test public void parseGermanLapTime(){assertEquals(492345,LapTracker.parse("8:12,345"));}
 @Test public void rejectAmbiguousTimes(){assertEquals(-1,LapTracker.parse("8:12.345 und 8:11.000"));}
 @Test public void acceptOnlyAfterStableDelay(){LapTracker l=new LapTracker();assertNull(l.observe("8:12.345",1000));assertNull(l.observe("8:12.345",2000));assertNotNull(l.observe("8:12.345",2900));assertNull(l.observe("8:12.345",5000));}
}
