# Green Hell Coach V2 — Android-Beta

Installierbare native Android-App (ab Android 8), für GT3/Nordschleife mit Handy-Kamera am TV.

## Änderungen in V2

- Dunkles, orange-rot-goldenes Race-Control-Dashboard.
- Deutsche Sprachausgabe: Renningenieur, Kommentator oder stumm; drei Intensitäten.
- CameraX-Vorschau und ML-Kit-OCR für die **eingefrorene letzte Rundenzeit**.
- Experimentelle Erkennung der roten/grünen Pedal-HUD-Anzeige durch RGB-Farbbereiche.
- Sprachhinweise bei erkannten Brems- und Gas-Signalwechseln und Rundenzeitvergleich.
- Einstellbare Kamera-Ausschnitte für Rundenzeit und Pedale.

## Wichtige Grenzen

Pedalerkennung ist eine experimentelle **Farbanalyse**, keine kalibrierte Messung des Bremspedaldrucks oder Gaswegs. Sie erkennt keine realen Bremspunkte, Kurven, Linien, Position oder Fahrfehler. Beim Kommentator werden ausschließlich erkannte Pedalereignisse und Zeitwerte angesagt, keine erfundenen Kurvennamen. Stark reflektierende Fernseher, andere HUD-Farben und schräger Kamerawinkel erschweren die Erkennung. Runde muss im Spiel eingefroren am HUD erscheinen.

## Benutzung

1. APK installieren und Kameraberechtigung geben.
2. Handy stabil auf PS4-Fernseher richten, das komplette HUD soll sichtbar sein.
3. Unter **Bildausschnitte** Rundenzeit und den roten/grünen Balkenbereich separat einstellen.
4. **Coaching starten** drücken; Sprachmodus und Intensität wählen.
5. Wenn die deutschsprachige Stimme fehlt, deutsche Text-to-Speech-Sprachdaten in Android installieren.

## Build

Android Gradle Plugin 8.7.3, Gradle 8.10.2, JDK 17, Android SDK 35.

Im Projektordner:

```bash
gradle --no-daemon :app:assembleDebug
```

Ausgabe: `app/build/outputs/apk/debug/app-debug.apk`.

Eine APK wurde mit dieser Version noch nicht gebaut bzw. auf dem Handy getestet; das Bauen erfolgt nach GitHub-Upload und GitHub-Actions-Lauf.
